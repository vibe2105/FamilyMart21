<html>
<head>
    <title>Delete Record</title>
</head>
<body>
    <form action="deleteRecord.php" method="post">
        Product Name: <input type="text" name="pName" size="30">
        <input type="submit" name="submit">
    </form>
</body>
</html>
