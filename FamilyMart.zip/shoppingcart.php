<?php
session_start();

$server_name = "localhost";
$username = "root";
$password = "";
$database_name = "register";

$conn = mysqli_connect($server_name, $username, $password, $database_name);

if (!$conn) {
    die("Connection Failed: " . mysqli_connect_error());
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Shopping Cart</title>
</head>
<body>

    <h1>Shopping Cart</h1>

    <?php
    if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
        // Display the items in the cart
        foreach ($_SESSION['cart'] as $product => $quantity) {
            echo "<p>Product: $product - Quantity: $quantity</p>";
        }
    } else {
        echo "<p>Your cart is empty.</p>";
    }
    ?>

    <br><br>
    <a href="product.html">Continue Shopping</a>

</body>
</html>
