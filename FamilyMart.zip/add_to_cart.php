<?php
session_start();

// Check if the 'product' parameter is set in the URL
if (isset($_GET['product'])) {
    $product = $_GET['product'];

    // If the 'cart' session isn't set, create it as an empty array
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // If the product already exists in the cart, increment the quantity
    if (array_key_exists($product, $_SESSION['cart'])) {
        $_SESSION['cart'][$product]++;
    } else {
        // Otherwise, add the product to the cart with a quantity of 1
        $_SESSION['cart'][$product] = 1;
    }

    // Redirect back to the product page after adding the item to the cart
    header('Location: product.html');
    exit();
}
?>
