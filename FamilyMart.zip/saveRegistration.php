<html>
<head>
    <title>FAMILY MART</title>
</head>
<body>
    <?php
    $date = date("d-m-Y");
    extract($_POST);
    ?>
    <p>Date: <b>
        <?php echo $date; ?>
    </b></p>
    <h3>FAMILY MART</h3>
    <table>
        <tr>
            <td>Product Name</td>
            <td>:</td>
            <td><b>
                <?php echo $pName; ?>
            </b></td>
        </tr>
        <tr>
            <td>Price</td>
            <td>:</td>
            <td><b>
                <?php echo $price; ?>
            </b></td>
        </tr>
        <tr>
            <td>Detail</td>
            <td>:</td>
            <td><b>
                <?php echo $detail; ?>
            </b></td>
        </tr>
        <tr>
                <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "register";
                
                $conn = new mysqli($servername, $username, $password, $dbname);
                
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $sql = "INSERT INTO product (pName, price, detail) VALUES (?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("sss", $pName, $price, $detail);
                
                $pName = $_POST['pName'];
                $price = $_POST['price'];
                $detail = $_POST['detail'];

                $stmt->execute();

                $stmt->close();
                $conn->close();
            ?>
            </b></td>
        </tr>
    </table>
</body>
</html>
