<?php
     session_start();

     include("db.php");

     if($_SERVER['REQUEST_METHOD'] == "POST")
     {
        $username = $_POST['uname'];
        $password = $_POST['pass'];
        $email = $_POST['email'];
        $number = $_POST['num'];
        
        $select = "SELECT * FROM form WHERE email = '$email' AND pass = '$password'";


        $result = mysqli_query($con, $select);

        if(!empty($email) && !empty($password) && !is_numeric($email))
        {
            $query = "insert into user (uname, pass, email, num) values ('$username','$password','$email','$number')";
            mysqli_query($con, $query);
            echo "<script type='text/javascript' > alert('Successfully Register')</script";
        }
        else
        {
            echo "<script type='text/javascript' > alert('Please enter some valid Information')</script";
        }
    }

?>

 <!DOCTYPE html>
<html lang="en">
<head>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;1,500&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        body {
            height: 100vh;
            width: 100%;
            background: #000;
        }

        .background {
            background: url(wallpaper2.jpg) no-repeat;
            background-position: center;
            background-size: cover;
            height: 100vh;
            width: 100%;
            filter: blur(10px);
        }

        .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 25px 13%;
            background: transparent;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 100;
        }

        .btnLogin-popup {
            width: 150px;
            height: 50px;
            background: #f72d7a;
            border: 2px solid #fff;
            outline: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 1.1em;
            color: #fff;
            font-weight: 500;
            margin-left: 20px;
            transition: 0.5s;
        }

        .btnLogin-popup:hover {
            background: #fff;
            color: #f72d7a;
        }

        .container {
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            width: 75%;
            height: 550px;
            margin-top: 20px;
            background: url(backgroun3.jpg) no-repeat;
            background-position: center;
            background-size: cover;
            border-radius: 20px;
            overflow: hidden;
        }

        .item {
            position: absolute;
            top: 0;
            right: 0;
            width: 58%;
            height: 50%;
            color: #fff;
            background: transparent;
            padding: 80px;
            display: flex;
            justify-content: space-between;
            flex-direction: column;
        }

        .item .logo {
            color: #fff;
            font-size: 30px;
        }

        .social-icon a i {
            color: #fff;
            font-size: 24px;
            margin-left: 10px;
            cursor: pointer;
            transition: .5s ease;
        }

        .login-section .form-box {
            position: absolute;
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            height: 100%;
        }

        .login-section .form-box.register {
            transform: translateX(0);
            transition: transform .6s ease;
            transition-delay: 0s;
        }

        .login-section.active .form-box.register {
            transform: translateX(430px);
            transition-delay: .7s;
        }

        .login-section .form-box.login {
            transform: translateX(0px);
            transition: transform .6s ease;
            transition-delay: 0.7s;
        }

        .login-section.active .form-box.login {
            transform: translateX(430px);
            transition-delay: 0s;
        }

        .login-section .form-box h2 {
            text-align: center;
            font-size: 25px;
        }

        .form-box .input-box {
            width: 340px;
            height: 50px;
            border-bottom: 2px solid #fff;
            margin: 30px 0;
            position: relative;
        }

        .input-box input {
            width: 100%;
            height: 100%;
            background: transparent;
            border: none;
            outline: none;
            font-size: 16px;
            padding-right: 28px;
        }

        .input-box label {
            position: absolute;
            top: 50%;
            left: 0;
            transform: translateY(-50%);
            font-size: 16px;
            font-weight: 600px;
            pointer-events: none;
            transition: .5s ease;
        }

        .input-box .icon {
            position: absolute;
            top: 13px;
            right: 0;
            font-size: 19px;
        }

        .input-box input:focus~ label,
        .input-box input:valid~ label {
            top: -5px;
        }

        .remember-password {
            font-size: 14px;
            font-weight: 500;
            margin: -15px 0 15px;
            display: flex;
            justify-content: space-between;
        }

        .remember-password label input {
            accent-color: #fff;
            margin-right: 3px;
        }

        .remember-password a {
            color: #fff;
            text-decoration: none;
        }

        .remember-password a:hover {
            text-decoration: underline;
        }

        .btn {
            background: #fff;
            width: 30%;
            height: 45px;
            outline: none;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            background: #f72d7a;
            font-size: 16px;
            color: #fff;
            box-shadow: rgba(0, 0, 0, 0.4);
        }

        .create-account {
            font-size: 14.5px;
            text-align: center;
            margin: 25px;
        }

        .create-account p a {
            color: #fff;
            font-weight: 600px;
            text-decoration: none;
        }

        .create-account p a:hover {
            text-decoration: underline;
        }
    </style>
    <title>FAMILY MART</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <!-- NAVBAR CREATION -->
   <header class="header"></header>
   </header>
    <!-- LOGIN FORM CREATION -->
    <div class="background"></div>
    <div class="container">
        <div class="item">
            <h2 class="logo"><img src="logo69.png"width="150" height="150">
        </div>
        <div class="form-box register">
            <div class="form-box register">
            <form action="" 
                method="POST">

                    <h2>Sign Up</h2>

                    <div class="input-box">
                        <span class="icon"><i class='bx bxs-user'></i></span>
                        <input type="text" name="uname" class="uname" required>
                        <label >Username</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i class='bx bxs-lock-alt' ></i></span>
                        <input type="password" name="pass" required>
                        <label>Password</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i class='bx bxs-envelope'></i></span>
                        <input type="email" name="email" class="email" required>
                        <label >Email</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i class='bx bx-phone'></i></span>
                        <input type="no" name="num" required>
                        <label >Phone Number</label>
                    </div>
                    <button class="btn">Sign Up</button>
                    <div class="create-account">
                        <p>Already Have an Account? <a href="login.php" class="register-link">Sign In</a></p>
                    </div>

                    
                </form>
            </div>
        </div>
    </div>
    <!-- SIGN UP FORM CREATION -->
    <script src="script.js"></script>
</body>
</html>
