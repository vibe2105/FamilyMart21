<html>
<head>
    <title>Delete Record</title>
</head>
<body>
    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "register";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if the 'pName' field is set in the $_POST array
    if (isset($_POST['pName'])) {
        // get input value
        $pName = $_POST['pName'];

        // sql to delete a record
        $sql = "DELETE FROM product WHERE pName='$pName'";
        if ($conn->query($sql) === TRUE) {
            echo "Record deleted successfully";
        } else {
            echo "Error deleting record: " . $conn->error;
        }
    } else {
        echo "No 'pName' field found in the form data.";
    }

    // close connection
    $conn->close();

    echo '<p><a href="admin.php">Back to Main Menu</a></p>';
    ?>
</body>
</html>
