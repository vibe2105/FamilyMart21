<?php
session_start();
include("db.php");

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $pName = $_POST['pName'];
    $price = $_POST['price'];
    $detail = $_POST['detail'];

    if (!empty($pName) && !empty($price) && !empty($detail)) {
        $query = "INSERT INTO product (pName, price, detail) VALUES ('$pName', '$price', '$detail')";
        $result = mysqli_query($con, $query);

        if ($result) {
            echo "<script type='text/javascript'>alert('Successfully added a new product')</script>";
        } else {
            echo "<script type='text/javascript'>alert('Failed to add the product. Please try again.')</script>";
        }
    } else {
        echo "<script type='text/javascript'>alert('Please enter valid information in all fields.')</script>";
    }
}
?>
