<?php
     $con = mysqli_connect("localhost", "root", "", "register");
?>